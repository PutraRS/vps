import cp, { exec as _exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import fetch from 'node-fetch'

const exec = promisify(_exec).bind(cp)

const THUMB_PATH = './media/code.jpeg'
const THUMB_URL = 'https://raw.githubusercontent.com/hamm-r/uploader/main/1784349730786-952.jpg'

async function getThumbnail() {
  try {
    return fs.readFileSync(THUMB_PATH)
  } catch {
    const res = await fetch(THUMB_URL)
    return Buffer.from(await res.arrayBuffer())
  }
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let ar = Object.keys(global.plugins)
  let ar1 = ar.map(v => v.replace('.js', ''))

  if (!text) {
    throw `uhm.. where the text?\n\nexample:\n${usedPrefix + command} info`
  }

  if (!ar1.includes(text)) {
    return m.reply(
      `*🗃️ NOT FOUND!*\n==================================\n\n${ar1
        .map(v => ' ' + v)
        .join('\n')}`
    )
  }

  let o
  try {
    o = await exec(`cat plugins/${text}.js`)
  } catch (e) {
    o = e
  }

  let { stdout = '', stderr = '' } = o

  if (stderr.trim()) return m.reply(stderr)
  if (!stdout.trim()) return m.reply('Plugin kosong.')

  const thumb = await getThumbnail()

  await conn.sendMessage(
    m.chat,
    {
      image: thumb,
      caption:
`📂 *Plugin Source*

📄 File : plugins/${text}.js
📦 Type : JavaScript (ESM)

Silakan gunakan tombol di bawah untuk menyalin source code.`,

      footer: wm,

      nativeFlow: [
        {
          text: '📋 Salin Source Code',
          copy: stdout
        },
        {
          text: '🏠 Menu',
          id: '.menu'
        },
        {
          text: '👑 Owner',
          id: '.owner'
        }
      ]
    },
    { quoted: m }
  )
}

handler.help = ['getplugin <nama>']
handler.tags = ['owner']
handler.command = /^(getplugin|gp)$/i
handler.owner = true

export default handler